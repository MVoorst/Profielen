import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { StudentDashboardComponent } from './student-dashboard/student-dashboard.component';
import { NieuweStudentComponent } from './nieuwe-student/nieuwe-student.component';
import { VragenCVComponent } from './vragen-cv/vragen-cv.component';
import { OverzichtIngevuldeVragenComponent } from './overzicht-ingevulde-vragen/overzicht-ingevulde-vragen.component';
import { FeedbackVanAdminComponent } from './feedback-van-admin/feedback-van-admin.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    StudentDashboardComponent,
    NieuweStudentComponent,
    VragenCVComponent,
    OverzichtIngevuldeVragenComponent,
    FeedbackVanAdminComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
