import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nieuwe-student',
  templateUrl: './nieuwe-student.component.html',
  styleUrls: ['./nieuwe-student.component.css']
})
export class NieuweStudentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
