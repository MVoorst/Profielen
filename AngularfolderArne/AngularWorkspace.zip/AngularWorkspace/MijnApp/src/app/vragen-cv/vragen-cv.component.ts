import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vragen-cv',
  templateUrl: './vragen-cv.component.html',
  styleUrls: ['./vragen-cv.component.css']
})
export class VragenCVComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
