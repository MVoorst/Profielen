import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VragenCVComponent } from './vragen-cv.component';

describe('VragenCVComponent', () => {
  let component: VragenCVComponent;
  let fixture: ComponentFixture<VragenCVComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VragenCVComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VragenCVComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
