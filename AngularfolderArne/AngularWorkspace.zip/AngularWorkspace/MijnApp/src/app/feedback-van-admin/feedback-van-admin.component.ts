import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-van-admin',
  templateUrl: './feedback-van-admin.component.html',
  styleUrls: ['./feedback-van-admin.component.css']
})
export class FeedbackVanAdminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
