import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FeedbackVanAdminComponent } from './feedback-van-admin.component';

describe('FeedbackVanAdminComponent', () => {
  let component: FeedbackVanAdminComponent;
  let fixture: ComponentFixture<FeedbackVanAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FeedbackVanAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FeedbackVanAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
