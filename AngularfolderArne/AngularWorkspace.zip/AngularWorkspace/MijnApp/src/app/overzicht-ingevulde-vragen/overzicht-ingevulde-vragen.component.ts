import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-overzicht-ingevulde-vragen',
  templateUrl: './overzicht-ingevulde-vragen.component.html',
  styleUrls: ['./overzicht-ingevulde-vragen.component.css']
})
export class OverzichtIngevuldeVragenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
