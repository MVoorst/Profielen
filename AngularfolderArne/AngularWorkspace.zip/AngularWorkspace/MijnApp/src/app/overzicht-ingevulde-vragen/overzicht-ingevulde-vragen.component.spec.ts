import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverzichtIngevuldeVragenComponent } from './overzicht-ingevulde-vragen.component';

describe('OverzichtIngevuldeVragenComponent', () => {
  let component: OverzichtIngevuldeVragenComponent;
  let fixture: ComponentFixture<OverzichtIngevuldeVragenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OverzichtIngevuldeVragenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverzichtIngevuldeVragenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
